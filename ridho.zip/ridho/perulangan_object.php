<?php

echo "Object Pirami Pada Perulangan PHP";
echo "<hr>";
echo "<br>";

$tinggi_piramid = 9;

for ($i = 1; $i <=$tinggi_piramid; $i++){
    for ($j =1; $j <=$tinggi_piramid - $i; $j++){
        echo " ";
    }
    for ($k= 1; $k <=$i; $k++){
        echo " *";
    }
}