<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Latihan Array</title>
</head>
<style>
    .nm{
        margin-top:3px;
    }
</style>
<body>
    <h3>Search Car</h3>
    <hr>
    <form method="POST">
        <table border="0">
            <tr>
                <td><label for="cn">Car Name</label></td>
                <td>:</td>
                <td><input type="text" id="cn" class="form-control" name="cn" placeholder="Car Name"></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td>
                    <input type="reset" class="btn btn-danger nm" name="reset" value="Reset">
                    <input type="submit" class="btn btn-success nm" name="search" value="search">
                </td>
            </tr>
        </table>
    </form>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>


<?php
if(isset($_POST["search"])){
$nama_mobil =["Avanza","Wuling","Ferari","Mercedes"];

$cn = $_POST["cn"];

$search = $cn;
$index = array_search($search, $nama_mobil);

if ($index !== false){
    echo "<br><hr><br>";
    echo "$search ada di dalam Array";
    echo "<br><hr><br>";
} else{
    echo "<br><hr><br>";
    echo "$search tidak ada di dalam Array";
    echo "<br><hr><br>";
}
}
?>